document.getElementById("myForm").addEventListener("submit", function(event){

    event.preventDefault();

    let name = document.getElementById("name").value.trim();
    let email = document.getElementById("email").value.trim();
    let phone = document.getElementById("phone").value.trim();
    let message = document.getElementById("message").value.trim();

    let result = document.getElementById("result");

    if(name === "" || email === "" || phone === "" || message === ""){
        result.innerHTML = "Please fill all fields";
        result.style.color = "red";
        return;
    }

    let emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;

    if(!email.match(emailPattern)){
        result.innerHTML = "Enter a valid email";
        result.style.color = "red";
        return;
    }

    if(phone.length !== 10){
        result.innerHTML = "Phone number must be 10 digits";
        result.style.color = "red";
        return;
    }

    result.innerHTML = "Form Submitted Successfully!";
    result.style.color = "green";

});