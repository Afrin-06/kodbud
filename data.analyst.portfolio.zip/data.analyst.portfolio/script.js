/* ============================================================
   DATAVAULT — Premium Data Analyst Portfolio
   script.js | All interactivity & animations
   ============================================================ */

'use strict';

/* ─────────────────────────────────────────────
   1. LOADER
───────────────────────────────────────────── */
window.addEventListener('load', () => {
  const loader = document.getElementById('loader');
  // Give fill animation time to complete, then hide loader
  setTimeout(() => {
    loader.classList.add('hidden');
    // Start hero animations after loader hides
    document.querySelectorAll('.hero .reveal').forEach(el => {
      el.classList.add('visible');
    });
    // Trigger hero canvas animation
    initHeroCanvas();
    // Start typing effect
    startTyping();
  }, 2000);
});

/* ─────────────────────────────────────────────
   2. NAVBAR — Sticky + Active Links + Hamburger
───────────────────────────────────────────── */
const navbar    = document.getElementById('navbar');
const hamburger = document.getElementById('hamburger');
const navLinks  = document.getElementById('navLinks');
const allNavLinks = document.querySelectorAll('.nav-link');

// Sticky on scroll
window.addEventListener('scroll', () => {
  if (window.scrollY > 40) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
  updateActiveNavLink();
  handleBackToTop();
  handleScrollReveal();
});

// Hamburger toggle
hamburger.addEventListener('click', () => {
  hamburger.classList.toggle('open');
  navLinks.classList.toggle('open');
});

// Close menu when a nav link is clicked
allNavLinks.forEach(link => {
  link.addEventListener('click', () => {
    hamburger.classList.remove('open');
    navLinks.classList.remove('open');
  });
});

// Active nav link based on scroll position
function updateActiveNavLink() {
  const sections = document.querySelectorAll('section[id]');
  let current = '';

  sections.forEach(section => {
    const sectionTop = section.offsetTop - 120;
    if (window.scrollY >= sectionTop) {
      current = section.getAttribute('id');
    }
  });

  allNavLinks.forEach(link => {
    link.classList.remove('active');
    if (link.getAttribute('href') === `#${current}`) {
      link.classList.add('active');
    }
  });
}

/* ─────────────────────────────────────────────
   3. HERO CANVAS — Particle Network
───────────────────────────────────────────── */
function initHeroCanvas() {
  const canvas  = document.getElementById('heroCanvas');
  if (!canvas) return;
  const ctx     = canvas.getContext('2d');
  const particles = [];
  const PARTICLE_COUNT = 60;
  const MAX_DIST       = 140;

  function resize() {
    canvas.width  = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  // Create particles
  for (let i = 0; i < PARTICLE_COUNT; i++) {
    particles.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.5,
      r: Math.random() * 2 + 1,
    });
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw connections
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx   = particles[i].x - particles[j].x;
        const dy   = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < MAX_DIST) {
          const alpha = (1 - dist / MAX_DIST) * 0.25;
          ctx.beginPath();
          ctx.strokeStyle = `rgba(0, 200, 255, ${alpha})`;
          ctx.lineWidth = 0.8;
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.stroke();
        }
      }
    }

    // Draw dots
    particles.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0, 200, 255, 0.55)';
      ctx.fill();

      // Move
      p.x += p.vx;
      p.y += p.vy;

      // Bounce off edges
      if (p.x < 0 || p.x > canvas.width)  p.vx *= -1;
      if (p.y < 0 || p.y > canvas.height) p.vy *= -1;
    });

    requestAnimationFrame(draw);
  }
  draw();
}

/* ─────────────────────────────────────────────
   4. TYPING EFFECT
───────────────────────────────────────────── */
const typingStrings = [
  'Data Analyst',
  'Power BI Developer',
  'SQL Specialist',
  'Python Enthusiast',
  'BI Dashboard Expert',
];
let tIdx = 0, cIdx = 0, isDeleting = false;

function startTyping() {
  const el = document.getElementById('typingText');
  if (!el) return;

  function type() {
    const current = typingStrings[tIdx];
    if (isDeleting) {
      el.textContent = current.substring(0, cIdx - 1);
      cIdx--;
    } else {
      el.textContent = current.substring(0, cIdx + 1);
      cIdx++;
    }

    let delay = isDeleting ? 60 : 110;

    if (!isDeleting && cIdx === current.length) {
      delay = 1800; // pause at full text
      isDeleting = true;
    } else if (isDeleting && cIdx === 0) {
      isDeleting = false;
      tIdx = (tIdx + 1) % typingStrings.length;
      delay = 400;
    }
    setTimeout(type, delay);
  }
  type();
}

/* ─────────────────────────────────────────────
   5. SCROLL REVEAL ANIMATIONS
───────────────────────────────────────────── */
function handleScrollReveal() {
  const reveals = document.querySelectorAll('.reveal:not(.visible)');
  const winH    = window.innerHeight;

  reveals.forEach(el => {
    const top = el.getBoundingClientRect().top;
    if (top < winH - 80) {
      el.classList.add('visible');
      // If it has progress bars, animate them
      animateProgressBars(el);
      // If it has stat counters, animate them
      animateCounters(el);
    }
  });
}

// Initial check on page load (for elements already in view)
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(handleScrollReveal, 100);
});

/* ─────────────────────────────────────────────
   6. ANIMATED COUNTERS
───────────────────────────────────────────── */
const animatedCounters = new Set();

function animateCounters(container) {
  // Find stat-numbers that are direct children or descendants
  const counters = container.closest
    ? document.querySelectorAll('.stat-card .stat-number')
    : container.querySelectorAll('.stat-number');

  document.querySelectorAll('.stat-number').forEach(el => {
    if (animatedCounters.has(el)) return;
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight - 60) {
      animatedCounters.add(el);
      const target = parseInt(el.dataset.target, 10);
      countUp(el, target);
    }
  });
}

function countUp(el, target) {
  let start = 0;
  const duration = 1600;
  const startTime = performance.now();

  function update(time) {
    const elapsed  = time - startTime;
    const progress = Math.min(elapsed / duration, 1);
    // Ease-out cubic
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.floor(eased * target);
    if (progress < 1) requestAnimationFrame(update);
    else el.textContent = target + '+';
  }
  requestAnimationFrame(update);
}

/* ─────────────────────────────────────────────
   7. ANIMATED PROGRESS BARS
───────────────────────────────────────────── */
const animatedBars = new Set();

function animateProgressBars(container) {
  document.querySelectorAll('.skill-fill').forEach(bar => {
    if (animatedBars.has(bar)) return;
    const rect = bar.getBoundingClientRect();
    if (rect.top < window.innerHeight - 40) {
      animatedBars.add(bar);
      const target = bar.dataset.width;
      setTimeout(() => {
        bar.style.width = target + '%';
      }, 100);
    }
  });
}

// Also trigger on scroll for skill bars independently
window.addEventListener('scroll', () => {
  document.querySelectorAll('.skill-fill').forEach(bar => {
    if (animatedBars.has(bar)) return;
    const rect = bar.getBoundingClientRect();
    if (rect.top < window.innerHeight - 40) {
      animatedBars.add(bar);
      const target = bar.dataset.width;
      setTimeout(() => { bar.style.width = target + '%'; }, 100);
    }
  });

  // Also trigger counters on scroll
  document.querySelectorAll('.stat-number').forEach(el => {
    if (animatedCounters.has(el)) return;
    const rect = el.getBoundingClientRect();
    if (rect.top < window.innerHeight - 60) {
      animatedCounters.add(el);
      const target = parseInt(el.dataset.target, 10);
      countUp(el, target);
    }
  });
});

/* ─────────────────────────────────────────────
   8. BACK TO TOP
───────────────────────────────────────────── */
const backToTopBtn = document.getElementById('backToTop');

function handleBackToTop() {
  if (window.scrollY > 400) {
    backToTopBtn.classList.add('show');
  } else {
    backToTopBtn.classList.remove('show');
  }
}

backToTopBtn.addEventListener('click', () => {
  window.scrollTo({ top: 0, behavior: 'smooth' });
});

/* ─────────────────────────────────────────────
   9. CONTACT FORM VALIDATION
───────────────────────────────────────────── */
const contactForm = document.getElementById('contactForm');
if (contactForm) {
  contactForm.addEventListener('submit', e => {
    e.preventDefault();
    let valid = true;

    // Helper: validate a field
    function validate(id, errorId, msg, check) {
      const field = document.getElementById(id);
      const error = document.getElementById(errorId);
      if (!check(field.value.trim())) {
        field.classList.add('error');
        error.textContent = msg;
        error.style.display = 'block';
        valid = false;
      } else {
        field.classList.remove('error');
        error.style.display = 'none';
      }
    }

    validate('fname', 'nameError', 'Please enter your full name.', v => v.length >= 2);
    validate('femail', 'emailError', 'Please enter a valid email address.',
      v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v));
    validate('fsubject', 'subjectError', 'Please enter a subject.', v => v.length >= 3);
    validate('fmessage', 'messageError', 'Message must be at least 20 characters.',
      v => v.length >= 20);

    if (valid) {
      // Simulate form submission (no backend)
      const btn = contactForm.querySelector('.form-submit');
      btn.disabled = true;
      btn.innerHTML = '<i class="fa-solid fa-circle-notch fa-spin"></i> Sending...';

      setTimeout(() => {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-solid fa-paper-plane"></i> Send Message';
        const successMsg = document.getElementById('formSuccess');
        successMsg.style.display = 'flex';
        contactForm.reset();
        // Hide success after 5s
        setTimeout(() => { successMsg.style.display = 'none'; }, 5000);
      }, 1800);
    }
  });

  // Live validation: clear error on input
  contactForm.querySelectorAll('input, textarea').forEach(field => {
    field.addEventListener('input', () => {
      field.classList.remove('error');
      const errorEl = document.getElementById(field.id.replace('f', '') + 'Error');
      if (errorEl) errorEl.style.display = 'none';
    });
  });
}

/* ─────────────────────────────────────────────
   10. SMOOTH SCROLL for anchor links
───────────────────────────────────────────── */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', e => {
    const target = document.querySelector(anchor.getAttribute('href'));
    if (target) {
      e.preventDefault();
      const offsetTop = target.offsetTop - 68; // 68px = navbar height
      window.scrollTo({ top: offsetTop, behavior: 'smooth' });
    }
  });
});

/* ─────────────────────────────────────────────
   11. MOUSE PARALLAX on Hero floating elements
───────────────────────────────────────────── */
const heroSection = document.getElementById('home');
if (heroSection) {
  heroSection.addEventListener('mousemove', e => {
    const { clientX, clientY } = e;
    const { innerWidth, innerHeight } = window;
    const dx = (clientX / innerWidth  - 0.5) * 20;
    const dy = (clientY / innerHeight - 0.5) * 20;

    document.querySelectorAll('.floating-elem').forEach((el, i) => {
      const factor = (i + 1) * 0.4;
      el.style.transform = `translate(${dx * factor}px, ${dy * factor}px)`;
    });
  });
}

/* ─────────────────────────────────────────────
   12. INIT on DOMContentLoaded
───────────────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  // Set initial reveal check
  setTimeout(() => {
    handleScrollReveal();
    handleBackToTop();
  }, 300);
});
